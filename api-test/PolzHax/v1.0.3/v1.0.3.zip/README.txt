Just put the files from this archive to the game folder with file replacement.

MOD IS NOT COMPATIBLE WITH MATS NICE HACKS

